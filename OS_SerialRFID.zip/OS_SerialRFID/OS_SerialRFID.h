#ifndef _OPENSMART_SERIAL_RFID_H_
#define _OPENSMART_SERIAL_RFID_H_

#include <Arduino.h>
#include <SoftwareSerial.h>

class SerialRFID{

private:
	SoftwareSerial myRFID;

public:

    SerialRFID(int pin):myRFID(pin,0xff)
    {
        myRFID.begin(9600);
    }
    
    unsigned long readIDDec(void)
	{
		char temp;
		char raw[14];
		char hexcode[8];
		while(myRFID.available()<14);
		for(unsigned char i=0;i < 14;i++)// 
		{
		  temp=myRFID.read();
		  raw[i] = temp;
		}       
		if((raw[0] == 0x02)&& (raw[13] == 0x03))
		{
		   for(unsigned char i=0;i < 8;i++){
			hexcode[i] = raw[i+3];
		   }
		}
		else return 0;
		unsigned long IDcode = 0;
		for(unsigned char i=0;i < 8;i++)//
		{
		  IDcode <<= 4;
		  if(hexcode[i]>0x40)  IDcode+=hexcode[i]-55;
		  else IDcode +=hexcode[i]-0x30;
		}
		return IDcode;
	}
	String readIDString(void)
	{
		unsigned long idcode;
		idcode = readIDDec();
		String id = String(idcode, DEC);
		uint8_t num = id.length();
		String newID="0000000000";
		for(uint8_t i=0;i<num;i++)
		{
			newID.setCharAt(10-num+i,id.charAt(i));
		}
		return newID;
	}
	void waitResume()
	{
	  char temp;
	  while(myRFID.available()){
		temp=myRFID.read();
		delay(1);
	  }
	  delay(500);
	  while(myRFID.available()){
		temp=myRFID.read();
		delay(1);
	  }
	}
	void listen(){myRFID.listen();}
};

#endif
/*********************************************************************************************************
  END FILE
*********************************************************************************************************/